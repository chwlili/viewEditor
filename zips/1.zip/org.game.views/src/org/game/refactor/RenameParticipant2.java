package org.game.refactor;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.ltk.core.refactoring.Change;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.TextFileChange;
import org.eclipse.ltk.core.refactoring.participants.CheckConditionsContext;
import org.eclipse.ltk.core.refactoring.participants.RenameParticipant;
import org.eclipse.text.edits.ReplaceEdit;

public class RenameParticipant2 extends RenameParticipant
{

	public RenameParticipant2()
	{
	}

	@Override
	protected boolean initialize(Object element)
	{
		return true;
	}

	@Override
	public String getName()
	{
		return "xx";
	}

	@Override
	public RefactoringStatus checkConditions(IProgressMonitor pm, CheckConditionsContext context) throws OperationCanceledException
	{
		return new RefactoringStatus();
	}

	@Override
	public Change createChange(IProgressMonitor pm) throws CoreException, OperationCanceledException
	{
		TextFileChange change=new TextFileChange("haha",ResourcesPlugin.getPlugin().getWorkspace().getRoot().getProject("tt").getFolder("views").getFolder("1v1").getFile("view.xml"));
		change.setEdit(new ReplaceEdit(0, 0, "gogo"));
		
		return change;
	}

}
